const board = Array(9).fill("");
let currentPlayer = "X";
let isGameActive = true;
let isAIMode = false;
let isMultiplayerMode = false;
let socket;
let roomId = null;

const winSound = document.getElementById('winSound');
const drawSound = document.getElementById('drawSound');
const loseSound = document.getElementById('loseSound');
const moveSound = new Audio('sounds/move.mp3');

const statusDisplay = document.getElementById('status');
const gameBoard = document.getElementById('gameBoard');

function renderBoard() {
  gameBoard.innerHTML = "";
  board.forEach((cell, index) => {
    const cellDiv = document.createElement('div');
    cellDiv.classList.add('cell');
    cellDiv.innerText = cell;
    cellDiv.addEventListener('click', () => makeMove(index));
    gameBoard.appendChild(cellDiv);
  });
}

function makeMove(index) {
  if (board[index] !== "" || !isGameActive) return;

  board[index] = currentPlayer;
  moveSound.play();
  renderBoard();
  checkResult();

  if (isAIMode && currentPlayer === "O" && isGameActive) {
    setTimeout(aiMove, 500);
  }

  if (isMultiplayerMode && currentPlayer === "O") {
    socket.emit('move', { index, roomId });
  }

  changePlayer();
}

function changePlayer() {
  currentPlayer = currentPlayer === "X" ? "O" : "X";
}

function aiMove() {
  let emptyIndices = board.map((val, idx) => val === "" ? idx : null).filter(v => v !== null);
  let aiChoice = emptyIndices[Math.floor(Math.random() * emptyIndices.length)];
  board[aiChoice] = currentPlayer;
  moveSound.play();
  renderBoard();
  checkResult();
  changePlayer();
}

function checkResult() {
  const winConditions = [
    [0,1,2], [3,4,5], [6,7,8],
    [0,3,6], [1,4,7], [2,5,8],
    [0,4,8], [2,4,6]
  ];

  for (let condition of winConditions) {
    const [a, b, c] = condition;
    if (board[a] && board[a] === board[b] && board[b] === board[c]) {
      isGameActive = false;
      announceWinner(currentPlayer);
      return;
    }
  }

  if (!board.includes("")) {
    isGameActive = false;
    announceWinner("draw");
  }
}

function announceWinner(winner) {
  if (winner === "draw") {
    drawSound.play();
    statusDisplay.innerText = "It's a Draw!";
  } else {
    if ((isAIMode && winner === "X") || (!isAIMode && winner === "X")) {
      winSound.play();
      statusDisplay.innerText = `Player ${winner} Wins! 🎉`;
    } else {
      loseSound.play();
      statusDisplay.innerText = `Player ${winner} Wins! 😞`;
    }
  }
}

function restartGame() {
  board.fill("");
  currentPlayer = "X";
  isGameActive = true;
  renderBoard();
  statusDisplay.innerText = "";
}

function startLocalGame() {
  isAIMode = false;
  isMultiplayerMode = false;
  restartGame();
}

function startAIGame() {
  isAIMode = true;
  isMultiplayerMode = false;
  restartGame();
}

function createRoom() {
  socket = io();
  socket.emit('createRoom');
  socket.on('roomCreated', (room) => {
    roomId = room;
    alert(`Room Created! Share this code: ${room}`);
    startMultiplayer();
  });

  socket.on('playerMove', ({ index }) => {
    if (currentPlayer === "O" && board[index] === "") {
      makeMove(index);
    }
  });
}

function joinRoom() {
  const input = document.getElementById('roomCodeInput').value.trim();
  if (input) {
    socket = io();
    socket.emit('joinRoom', input);
    socket.on('roomJoined', (room) => {
      roomId = room;
      alert(`Joined Room: ${room}`);
      startMultiplayer();
    });

    socket.on('playerMove', ({ index }) => {
      if (currentPlayer === "O" && board[index] === "") {
        makeMove(index);
      }
    });
  }
}

function startMultiplayer() {
  isMultiplayerMode = true;
  isAIMode = false;
  restartGame();
}

renderBoard();