const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);

app.use(express.static('public'));

io.on('connection', (socket) => {
  console.log('New user connected');

  socket.on('createRoom', () => {
    const room = Math.random().toString(36).substring(2, 7);
    socket.join(room);
    socket.emit('roomCreated', room);
  });

  socket.on('joinRoom', (room) => {
    socket.join(room);
    socket.emit('roomJoined', room);
  });

  socket.on('move', ({ index, roomId }) => {
    socket.to(roomId).emit('playerMove', { index });
  });
});

const PORT = process.env.PORT || 3000;
http.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});